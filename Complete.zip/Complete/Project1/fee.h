//
//#include<iostream>
//#include<fstream>
#include<string>
#include<iomanip>
using namespace std;
class Fee
{
private:

	string fee;
	int counter = 0;
public:

	void feeStatus();


};
void Fee::feeStatus()
{

	ifstream fee_in;
	fee_in.open("student.txt", ios::app);
	if (fee_in.is_open())
	{
		while (!fee_in.eof())
		{
			fee_in >> fee;
			if (counter == 0 || counter == 1 || counter == 2 || counter == 10)
			{
				cout << fee << left << setw(10);
			}
			counter++;
			if (counter == 13)
			{
				counter = 0;
				cout << endl;
			}
		}
	}
	else
		cout << "Error" << endl;

}
