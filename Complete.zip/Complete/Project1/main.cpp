#include<iostream>
#include<string>
#include<iomanip>
#include"threefile.h"
#include"student.h"
#include"Teacher.h"
#include"Marks.h"
#include"fee.h"
#include"Courses.h"
#include"teacher_courses.h"
using namespace std;
void credits()
{
	system("Color 70");
	int i = 0;
	do {
		system("cls");
		//zain
		Sleep(150);
		cout << "\t\t\t\t\t** C R E D I T S ***\n\n\n";
		Sleep(150);
		cout << "****\t\t\t *\t\t\t***   \t\t\n";
		Sleep(150);
		cout << "          *\t\t     *\t     *\t\t\t   *\t   *  \t\t\n";
		Sleep(150);
		cout << "        *\t\t    *\t\t*\t\t   *\t   *    \t\n";
		Sleep(150);
		cout << "      *\t\t  *\t\t   *\t\t   *\t   *      \t\n";
		Sleep(150);
		cout << "   *\t\t       * * * * * * * * * * * *\t\t   *\t   *       \t\n";
		Sleep(150);
		cout << "  *\t\t     *\t\t\t       *\t   *\t   *        *   *\n";
		Sleep(150);
		cout << "*\t\t  *\t\t\t         *\t   *\t   *          \t\n";
		Sleep(150);
		cout << "****\t*\t\t\t           *\t***   \t\t\n";
		cout << "\n\n\t\t\t\t\tA N D\n\n";
		//Maaz
		Sleep(1000);
		cout << "*               *            *                          *                  ****\n";
		Sleep(150);
		cout << "* *           * *          *    *                      *    *                          **\n";
		Sleep(150);
		cout << "*  *         *  *         *       *                  *        *                      **\n";
		Sleep(150);
		cout << "*   *       *   *       *           *              *             *                 **\n";
		Sleep(150);
		cout << "*    *     *    *     * * * * * * * * *          * * * * * * * * * *             **\n";
		Sleep(150);
		cout << "*     *  *      *    *                  *      *                     *         **\n";
		Sleep(150);
		cout << "*      *        *  *                      *  *                         *      ****\n";
		cout << "\n\t\tTHANK YOU FOR USING SCHOOL MANAGEMENT SYSTEM \n\n";
		Sleep(1500);
		i = i + 1;
	} while (i != 3);
}
class Menu
{
public:
	void dis()
	{
		system("COLOR 70");
		cout << endl << endl << "        ";
		for (int c = 0; c<30; c++)					// ----> The main heading line
		{
			cout << "*";
		}
		cout << "  _Welcome to The School Management System_  ";
		for (int c = 0; c<30; c++)
		{
			cout << "*";
		}
		cout << endl;
		cout << endl;

		cout << "\t\t\t\t Please Enter the password to gain access to the system : " << endl << endl;
	}
	void dis1()
	{
		cout << endl << endl << "\t\t\t\t >>>>>>>>>  School Managment System  <<<<<<<<<" << endl;
		cout << "\t\t\t\t   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ " << endl;
		cout << "\t\t\t\t  | Press  1 to gain access to Admin Mode        |" << endl;
		cout << "\t\t\t\t  |                                              |" << endl;
		cout << "\t\t\t\t  | Press  2 to gain access to Teacher Mode      |" << endl;
		cout << "\t\t\t\t  |                                              |" << endl;
		cout << "\t\t\t\t  | Press  3 to gain access to Student Mode      |" << endl;
		cout << "\t\t\t\t  |                                              |" << endl;
		cout << "\t\t\t\t  | Press  0 to Exit                             |" << endl;
		cout << "\t\t\t\t   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ " << endl;
		cout << "\t\t\tInput Your Choice : ";
		cout << endl << " Please enter your choice (1-3) :   ";
	}
	void dis2()
	{
		cout << endl << endl << "\t\t\t\t>>>>>>>>>  School Managment System  <<<<<<<<<" << endl;
		cout << endl << endl << "\t\t\t\t................Admin Mode..................." << endl;
		cout << "\t\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << "\t\t\t\t| Press  1:   To Add New Student              |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press  2:   To Add New Teacher              |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press  3:   To Add New Course               |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press  4:   To Assign Course                |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press  5:   To Update Student               |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press  6:   To Update Teacher               |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press  7:   To View All Students            |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press  8:   To View All Teachers            |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press  9:   To View All Courses             |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press 10:   To Update Student Marks         |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press 11:   To View Student Marks           |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press 12:   To View Fee Status              |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press 13:   To start new session            |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press 14:   To return to main menu          |" << endl;
		cout << "\t\t\t\t|                                             |" << endl;
		cout << "\t\t\t\t| Press  0:   To Exit                         |" << endl;
		cout << "\t\t\t\t ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl << endl;
		cout << "\t\t\t\tInput Your Choice : ";
	}
	void dis3()
	{

		cout << endl << endl << "\t\t\t\t >>>>>>>>>  Teacher Section   <<<<<<<<<" << endl;
		cout << "\t\t\t\t   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ " << endl;
		cout << "\t\t\t\t  | Press  1 to Veiw courses Assinged            |" << endl;
		cout << "\t\t\t\t  |                                              |" << endl;
		cout << "\t\t\t\t  | Press  2 to assing marks to students         |" << endl;
		cout << "\t\t\t\t  |                                              |" << endl;
		cout << "\t\t\t\t  | Press  3 to go to main menu                  |" << endl;
		cout << "\t\t\t\t  |                                              |" << endl;
		cout << "\t\t\t\t  | Press  0 to Exit                             |" << endl;
		cout << "\t\t\t\t   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ " << endl;
		cout << "\t\t\tInput Your Choice : ";
		cout << endl << " Please enter your choice (1-2) :   ";
	}
	void dis4()
	{
		cout << endl << endl << "\t\t\t\t >>>>>>>>>  Student Section   <<<<<<<<<" << endl;
		cout << "\t\t\t\t   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ " << endl;
		cout << "\t\t\t\t  | Press  1 to Veiw Marks                       |" << endl;
		cout << "\t\t\t\t  |                                              |" << endl;
		cout << "\t\t\t\t  | Press  2 to check Fee status                 |" << endl;
		cout << "\t\t\t\t  |                                              |" << endl;
		cout << "\t\t\t\t  | Press  3 to go to main menu                  |" << endl;
		cout << "\t\t\t\t  |                                              |" << endl;
		cout << "\t\t\t\t  | Press  0 to Exit                             |" << endl;
		cout << "\t\t\t\t   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ " << endl;
		cout << "\t\t\tInput Your Choice : ";
		cout << endl << " Please enter your choice (1-2) :   ";
	}
};
class TryPass
{
private:
	string pw;
	int loginTry;
	int a;
public:

	bool trypass()
	{
		loginTry = 0;
		a = 2;
		while (loginTry <= 0)

		{
			cout << "                                              ";
			cin >> pw;		// ----> input password string for login to the library
			if (pw == "p")
			{
				system("cls");
				loginTry = 1;
			}
			else
			{
				cout << "\n\t   You entered the wrong password, please try again by pressing another password. " << a << " tries left.\n\n\n";
				loginTry--;
				a--;
			}
			if (loginTry == -3)
			{
				cout << "\n\t\t\t   You tried many times.The system is exiting. " << endl << endl;
				return false;

			}
		}
	}
};

int main()
{
	string n;
	Menu a;
	TryPass t;
	Admin d;
	Student obj_S;
	Teacher obj_T;
	Fee obj_F;
	Course obj_C;
	Marks obj_M;


	a.dis();
	if (t.trypass() == 0)
	{
		goto exit;
	}
top1:		// ----> defining label for first screen
	a.dis1();
	cin >> n;
	if (n == "1")
	{	//----------------------------------------------------------------------------------------
		// ADMIN MODE
		if (d.isLogin() == 1)
		{
		top2:
			system("cls");
			a.dis2();
			cin >> n;
			if (n == "1")
			{
				obj_S.add();
				Sleep(5000);
				goto top2;
			}
			if (n == "2")
			{
				obj_T.add();
				Sleep(5000);
				goto top2;
			}
			if (n == "3")
			{
				obj_C.assignCourses();
				goto top2;
			}
			if (n == "4")
			{
			 obj_C.assignCourses();

			 Sleep (5000);
				goto top2;
			}
			if (n == "5")
			{
				obj_S.update();
				Sleep(5000);
				goto top2;
			}
			if (n == "6")
			{
				obj_T.update();
				Sleep(5000);
				goto top2;
			}
			if (n == "7")
			{
				obj_S.veiw();
				Sleep(5000);
				goto top2;
			}
			if (n == "8")
			{
				obj_T.veiw();
				Sleep(5000);
				goto top2;
			}
			if (n == "9")
			{
				obj_C.detailsCourses();
				goto top2;
			}
			if (n == "10")
			{
				cout << "UNder Construction";
				goto top2;
			}
			if (n == "11")
			{
				obj_C.viewAllCourses();
				goto top2;
			}
			if (n == "12")
			{
				obj_F.feeStatus();
				goto top2;
			}
			if (n == "13")
			{
				cout << "Under Construction" << endl;
				//start new session
				goto top1;
			}
			if (n == "14")
			{
				system("cls");
				goto top1;
			}

			if (n == "0")
			{
				goto exit;
			}
			else
			{
				cout << "\n Invalid Entry. Please try again. \n\n";
				system("pause");
				goto top2;
			}
		}
		else
		{
			if (d.isLoginTry() == 1)
			{
				goto top2;
			}
		}
	}

	if (n == "2")
	{//---------------------------------------------------------------------
	 // Teacher SECTION

	 //if (T.isLogin() == 1)
	 //{
	top3:
		system("cls");
		a.dis3();
		cin >> n;
		if (n == "1")
		{
			
			goto top3;
		}

		if (n == "2")
		{
			obj_M.viewMarks();
			goto top3;
		}

		if (n == "3")
		{
			system("cls");
			goto top1;
		}

		if (n == "0")
		{
			goto exit;
		}
		else
		{
			cout << "\n Invalid Entry. Please try again. \n\n";
			system("pause");
			goto top2;
		}
	}
	//}
	//---------------------------------------------------------------------
	// Student SECTION
	if (n == "3")
	{
		//if (p.isLogin() == 1)
		//{
	top4:
		system("cls");
		a.dis3();
		cin >> n;
		if (n == "1")
		{
			obj_M.viewMarks();
			goto top4;
		}

		if (n == "2")
		{
 obj_F.feeStatus();
			goto top3;
		}

		if (n == "3")
		{
			system("cls");
			goto top1;
		}

		if (n == "0")
		{
			goto exit;
		}
		else
		{
			cout << "\n Invalid Entry. Please try again. \n\n";
			system("pause");
			goto top2;
		}
	}
	//}
	else
	{
		cout << "\n Invalid Entry. Please try again. \n\n";
		system("pause");
		system("cls");
		goto top1;
	}
	credits();
exit:
	system("pause>0");
}
