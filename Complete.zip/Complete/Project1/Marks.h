#pragma once
#define MARKS_H_INCLUDED
#include<string>
#include<iostream>
#include"threefile.h"
using namespace std;
class Marks :public Admin 
{
	string find;
public:
	void enterMarks();
	void viewMarks();
	void upMarks();//--->update marks
	void viewParentCourse();
};
void Marks::enterMarks()
{
	ifstream read;
	ofstream write;
	read.open("Marks_updation.txt");
	write.open("Temp.txt");
	if (read.is_open())
	{
		if (write.is_open())
		{
			
				counter = 0;
				cout << "Enter Roll number of student you want to update marks";
				cin >> find;
				while (!read.eof()){
					counter++;
					if (counter == 5)
					{
						write << endl;
						counter = 0;
					}
					check = true;


					read >> finder;

					if (finder == find)
					{
						cout << "\nEnter the number of student ::" << finder;
						write << finder << " ";
						read >> finder;
						counter++;
						cout << "\nEnter the number of subject      ::" << finder;
						write << finder << "     ";
						cout << "\nEnter the marks of student       :: ";
						cin >> find;
						write << find << " ";
						read >> finder;
						counter++;
						cout << "\nEnter the Total Marks of student :: ";
						cin >> find;
						write << find;
						check = false;

					}
					if (check == true)
					{
						if (finder != " ")
							write << finder << "  ";
					}
			

			}
		}
	}
	read.close();
	write.close();
	remove("Marks_updation.txt");
	rename("Temp.txt", "Update Marks.txt");

}
void Marks::upMarks()
{
	ifstream read;
	ofstream write;
	read.open("Temp.txt");
	write.open("Marks_updation.txt");
	counter = 0; rollNum = 0;
	if (read.is_open())
	{
		if (write.is_open())
		{
			while (!read.eof())
			{

				getline(read, finder);
				write << finder;

			}
		}
	}
}

void Marks::viewMarks()
{
	ifstream read;
	read.open("Marks_updation.txt");
	if (read.is_open())
	{
		counter = 0;
		while (!read.eof())
		{
			getline(read, finder);
			cout << finder << endl;
		}
	}
}

void Marks::viewParentCourse()
{
	ifstream read;
	read.open("Marks_updation.txt");
	if (read.is_open())
	{
		check = true;
		counter = 0;
		cout << "\nEnter the Roll Number   ::";
		cin >> rollNum;
		while (!read.eof())
		{
			read >> finder;
			if (finder== find)
			{
				cout << finder;
				getline(read, finder);
				cout << finder << endl;
				check = false;
			}
		}
		if (check == true)
			cout << "\nNo Record found";
	}
}


//
//void Marks::enterMarks()
//{
//	ifstream read;
//	ofstream write;
//	read.open("Temp.txt");
//	write.open("Update Marks.txt");
//	count = 0; RollNum = 0;
//	if (read.is_open())
//	{
//		if (write.is_open())
//		{
//			while (!read.eof())
//			{
//
//				read >> searching;
//				if (RollNum == 0)
//					write << searching << "   ";
//				else
//				{
//					write << searching << "      ";
//				}
//				count++;
//				if (count == 4)
//				{
//					write << "\n";
//					count = 0;
//					RollNum++;
//				}
//
//
//			}
//		}
//	}
//}
//
//void Marks::viewMarks()
//{
//	ifstream read;
//	read.open("Update Marks.txt");
//	if (read.is_open())
//	{
//		count = 0;
//		while (!read.eof())
//		{
//			getline(read, searching);
//			cout << searching << endl;
//		}
//	}
//}
//void fee_Status::display_Fee() {
//
//	ifstream read;
//	read.open("Student.txt", ios::app);
//	if (read.is_open())
//	{
//		while (!read.eof())
//		{
//			read >> fee1;
//			if (count == 0 || count == 1 || count == 2 || count == 10)
//			{
//				cout << fee1 << "\t";
//
//			}
//			count++;
//			if (count == 13)
//			{
//				count = 0;
//				cout << endl;
//			}
//		}
//	}
//	else
//		cout << "Fee status can not be loaded" << endl;
//
//
//}
//void Marks::upMarks()
//{
//	ifstream read;
//	read.open("Update Marks.txt");
//	if (read.is_open())
//	{
//		cheak = true;
//		count = 0;
//		cout << "\nEnter the Roll Number   ::";
//		cin >> Address;
//		while (!read.eof())
//		{
//			read >> searching;
//			if (Address == searching)
//			{
//				cout << searching;
//				getline(read, searching);
//				cout << searching << endl;
//				cheak = false;
//			}
//		}
//		if (cheak == true)
//			cout << "\nNo Record found";
//	}
//}
//
