#pragma once
#define threefile_H_INCLUDED
#include<string>
#include<iostream>
#include<fstream>
#include<Windows.h>
#include<iomanip>
using namespace std;
struct Date
{
	int day = 0;
	int month = 0;
	int year = 0;
};
class Admin
{
protected:
	string ad_name;				// ----> admin names
	string ad_pw;				// ----> admin passwords
	string adm_name;			// ----> strings to hold input credentials 
	string adm_pw;
	string try_top;
	bool login;
	bool log;
	string std_firstName;
	string std_lastName;
	string fatherName;
	string teacher_firstName;
	string teacher_lastName;
	string courseName;
	string student_phone;
	string father_phone;
	string teacher_phone;
	string student_email;
	string teacher_email;
	string student_address;
	string teacher_address;
	string Reg_Date, blood;
	string password, confirmation;
	string	qualification, DOB, finder;
	int ID;
	int age;
	char Gender;
	string CNIC;
	string father_profession;
	char a, feeStatus;
	int  Class, rollNum, counter;
	bool check;
	ifstream admin;
public:
	//Admin();
	string get_std_firstName() const;			 // ---->Student first name
	void   set_std_firstName(string);

	string get_std_lastName() const;		    // ---->Student last name
	void   set_std_lastName(string);

	string get_fatherName() const;			    // ---->fATHER  name
	void   set_fatherName(string);

	string get_teacher_firstName() const;	   // ---->tEACHER first name
	void   set_teacher_firstName(string);

	string get_teacher_lastName() const;	   // ---->tEACHER last name
	void   set_teacher_lastName(string);

	string get_courseName() const;		      // ---->COURSE name
	void   set_courseName(string);

	void set_studentphone(string);
	void set_fatherphone(string);
	void set_teacherphone(string);
	void set_student_email(string);
	void set_teacher_email(string);
	void set_student_address(string);
	void set_teacher_address(string);
	void setID(int);
	void setAge(int);
	void setGender(char);
	void setCNIC(string);
	void set_father_profession(string);

	int getID() const;
	int getAge() const;
	char getGender() const;
	string getCNIC() const;
	string get_father_profession() const;

	string get_studentphone() const;
	string get_fatherphone() const;
	string get_teacherphone() const;
	string get_student_email() const;
	string get_teacher_email() const;
	string get_student_address() const;
	string get_teacher_address() const;

	void set_regDate(string);
	string get_regDate() const;

	void set_rollNum(int);
	int get_rollNum() const;

	void set_Class(int);
	int get_Class() const;

	void set_Fee(int);
	int get_Fee() const;


	bool isLogin();
	bool isLoginTry();

};
class Fee
{
private:

	string fee;
	int counter = 0;
public:

	void feeStatus();


};
void Fee::feeStatus()
{

	ifstream fee_in;
	fee_in.open("student.txt", ios::app);
	if (fee_in.is_open())
	{
		while (!fee_in.eof())
		{
			fee_in >> fee;
			if (counter == 0 || counter == 1 || counter == 2 || counter == 10)
			{
				cout << fee << left << setw(10);
			}
			counter++;
			if (counter == 17)
			{
				counter = 0;
				cout << endl;
			}
		}
	}
	else
		cout << "Error" << endl;

}
bool Admin::isLogin()			// ----> Function for authenticating the admin login through saved credentials in a file.
{
	system("cls");
	Admin data[3];		// ----> Structure Array for storing the read data from the file				
	admin.open("Admin_logs.txt");// ----> Opening the file for reading
	for (int i = 0; i < 3; i++)
	{
		admin >> data[i].ad_name;
		admin >> data[i].ad_pw;
	}

	login = false;
	cin.ignore();
	cout << " Enter the name of admin: ";		// ----> taking input for credentials
	getline(cin, adm_name);
	cout << " Enter the admin password: ";
	getline(cin, adm_pw);

	for (int i = 0; i < 3; i++)
	{
		if (adm_name == data[i].ad_name && adm_pw == data[i].ad_pw)           // ----> checking for password and user name match
		{
			cout << "\n\n\n\tLOADING \n\t\t\t\t\t";
			for (int a = 1; a < 11; a++) //
			{
				Sleep(500);
				cout << "...";
			}
			cout << "\n\n\n\t\t\t\t\tAccess Granted!! \n\n\n";

			cout << "\n\n You are successfully logged in ADMIN mode \n\n";
			login = true;
		}
	}
	admin.close();
	return login;															// ----> returning the login value to the function
}
bool Admin::isLoginTry()
{
	cout << endl << " Wrong Ussername or Password  Entered!!!!!\n\n" << endl;
	log = false;
	cout << " Do you want to choose another choice ? (y/n)    ";
	cin >> try_top;					// ----> string input for decision
	if (try_top == "y" || try_top == "Y")
	{
		system("cls");
		if (isLogin() == 1)
		{
			log = true;
			system("pause");
			return log;
		}
		else
		{
			isLoginTry();
		}

	}
	else if (try_top == "n" || try_top == "N")
	{
		system("pause");
		exit(0);
	}
	else
	{
		cout << endl << endl << " Wrong choice entered!! The system is exiting due to the wrong format used in admin login. " << endl << endl;
		system("pause");
		exit(0);
	}
	return log;

}

void Admin::set_std_firstName(string n)
{
	std_firstName = n;
}

string  Admin::get_std_firstName() const
{
	return std_firstName;
}
void Admin::set_std_lastName(string n)
{
	std_lastName = n;
}

string  Admin::get_std_lastName() const
{
	return std_lastName;
}
void Admin::set_fatherName(string n)
{
	fatherName = n;
}

string  Admin::get_fatherName() const
{
	return fatherName;
}
void Admin::set_teacher_firstName(string n)
{
	teacher_firstName = n;
}

string  Admin::get_teacher_firstName() const
{
	return teacher_firstName;
}
void Admin::set_teacher_lastName(string n)
{
	teacher_lastName = n;
}

string  Admin::get_teacher_lastName() const
{
	return teacher_lastName;
}
void Admin::set_courseName(string n)
{
	courseName = n;
}

string  Admin::get_courseName() const
{
	return courseName;
}

void Admin::set_studentphone(string p)
{
	student_phone = p;
}
void Admin::set_fatherphone(string p)
{
	father_phone = p;
}
void Admin::set_teacherphone(string p)
{
	teacher_phone = p;
}
void Admin::set_student_email(string e)
{
	student_email = e;
}
void Admin::set_teacher_email(string e)
{
	teacher_email = e;
}
void Admin::set_student_address(string e)
{
	student_address = e;
}
void Admin::set_teacher_address(string e)
{
	teacher_address = e;
}

string Admin::get_studentphone() const
{
	return student_phone;
}
string Admin::get_fatherphone() const
{
	return father_phone;
}
string Admin::get_teacherphone() const
{
	return teacher_phone;
}
string Admin::get_student_email() const
{
	return student_email;
}
string Admin::get_teacher_email() const
{
	return teacher_email;
}
string Admin::get_student_address() const
{
	return student_address;
}
string Admin::get_teacher_address() const
{
	return teacher_address;
}

void Admin::set_regDate(string Rd)
{
	Reg_Date = Rd;

}
string Admin::get_regDate() const
{
	return Reg_Date;
}

void Admin::set_rollNum(int R)
{
	rollNum = R;
}
int Admin::get_rollNum() const
{
	return rollNum;
}

void Admin::set_Class(int c)
{
	Class = c;
}
int Admin::get_Class() const
{
	return Class;
}

void Admin::set_Fee(int f)
{
	feeStatus = f;

}
int Admin::get_Fee() const
{
	return feeStatus;
}

