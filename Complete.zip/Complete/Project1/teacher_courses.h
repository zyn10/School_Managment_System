#pragma once
#define Teacher_COURSES_H_INCLUDED
#include<string>
#include<fstream>
#include<iostream>
#include<iomanip>
#include"threefile.h"
class Teacher_Courses :public Admin
{
private:
	string view, view1;
	int x;
public:
	int a;
	void viewAssingedCourses();
	void upation_marks();
	bool ID_T();
	bool pass();
};

void Teacher_Courses::viewAssingedCourses()
{

	ifstream read;
	read.open("T_Course.txt", ios::app);
	cout << "Input" << endl;
	cin >> view;
	if (read.is_open())
	{
		cout << "Teachers Name    Course Name           Class+Section     Total Registered Students" << endl;
		while (!read.eof())
		{
			read >> view1;

			if (view1 == view)
			{
				cout << view1 << "\t";
				getline(read, view1);
				cout << view1;
			}
		}

	}
	else
		cout << "Courses File Could Not Be Loaded" << endl;
}
void Teacher_Courses::upation_marks()
{
	ifstream read;
	ofstream write;
	read.open("Temp.txt");
	write.open("Marks_updation.txt");
	counter = 0; rollNum = 0;
	cout << "Enter Roll Number" << endl;
	cin >> view;
	if (read.is_open())
	{
		if (write.is_open())
		{
			while (!read.eof())
			{

				read >> finder;
				if (view == finder)
					write << finder << "   ";
				else
				{
					write << finder << "      ";
				}
				counter++;
				if (counter == 4)
				{
					write << "\n";
					counter = 0;
					rollNum++;
				}


			}
		}
	}
}

bool Teacher_Courses::ID_T()
{
	ifstream read;
	read.open("teacher.txt");

	if (read.is_open())
	{
		x = 0;
		cin >> view;
		while (!read.eof())
		{
			read >> view1;
			if (view1 == view)
				return true;
		}
	}
	read.close();
	return 0;
}
bool Teacher_Courses::pass()
{
	ifstream read;
	read.open("teacher.txt");

	if (read.is_open())
	{
		x = 0;
		cin >> view;
		while (!read.eof())
		{
			read >> view1;
			if (view1 == view)
				return true;

		}
		return false;
	}
	read.close();
	return 0;
}
/*
bool ID_Password::_ID_()
{
ifstream read;
read.open("Student ID Password.txt");
cin >> ID_;
while (!read.eof())
{
read >> searching;
if (searching == ID_)
return true;

}
return false;

}
bool ID_Password::Student_Password()
{
ifstream read;
read.open("Student ID Password.txt");
cin >> ID_;
while (!read.eof())
{
read >> searching;
if (searching == ID_)
return true;

}
return false;
}
*/#pragma once
