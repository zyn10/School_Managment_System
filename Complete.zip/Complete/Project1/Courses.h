#pragma once
#define Courses_H_INCLUDED
#include<string>
#include<fstream>
#include<iostream>
#include<iomanip>
#include"threefile.h"
using namespace std;
class Teacher;//forward declaration
class Course 
{
private:
	
	
	string courseName,courseCode,classNumber,parentCode;
	string course;
	string assign,assign1,assign2;
	string display;
	string parent,teacher;
	char array[1500];
	int x = 0;
public:

	void open_File();
	void assignCourses();
	void viewAllCourses();
	void detailsCourses();

};


void Course::detailsCourses()
{

	fstream write;
	write.open("Courses.txt", ios::app);
	if (write.is_open())
	{
		cout << "Enter Course Name" << endl;
		cin >> courseName;
		courseName = courseName + " ";
		cout << endl;
		cout << "Enter Course Code" << endl;
		cin >> courseCode;
		courseCode = courseCode + " ";
		cout << endl;
		cout << "Select Class from 1 to 10" << endl;
		cin >> classNumber;

		classNumber = classNumber + " ";
		cout << endl;
		cout << "Enter Parent Course" << endl;
		cin >> parentCode;
		parentCode = parentCode + " ";

		course = courseName + courseCode + classNumber + parentCode;
		write << "\n";

		write << course;

		write.close();
	}
	else
		cout << "Error" << endl;



}

void Course::assignCourses()
{
	ifstream course_reading;
	fstream course_writing;
	x = 0;
	course_reading.open("Teacher.txt", ios::app);
	if (course_reading.is_open()) {
		while (!course_reading.eof())
		{
			if (x == 1 || x == 7)
			{
				course_reading >> teacher;

				teacher = teacher + "\t";
				cout << teacher;
			}
			course_reading >> teacher;
			x++;
			if (x == 12)
			{

				cout << endl;
				x = 0;
			}


		}
	}
	else
		cout << "Teacher file loading ERROR" << endl;

	course_reading.close();
	cout << endl << endl;
	cout << "The courses to be assigned are" << endl << endl;
	course_reading.open("Courses.txt", ios::app);
	if (course_reading.is_open())
		while (!course_reading.eof())
		{
			(getline(course_reading, courseName));

			courseName = courseName + "\n";

			cout << courseName;
		}
	course_reading.close();
	cout << endl;
	cout << "Enter Course to Assign" << endl;
	getline(cin, assign1);
	assign1 = assign1 + " ";
	cout << endl;
	cout << "Enter Teacher's Name" << endl;
	getline(cin, assign2);
	assign2 = assign2 + " ";
	assign = assign1 + assign2;
	course_writing.open("T_course.txt", ios::app);
	{
		course_writing << "\n";
		course_writing << select;
	}
	course_reading.close();
}
void Course::viewAllCourses() {
	ifstream read;
	read.open("course.txt", ios::app);
	if (read.is_open())
	{
		while (!read.eof())
		{

			getline(read, course);
			cout << course << endl;
		}

	}
	else
		cout << "Courses File could not be loaded" << endl;


	read.close();
}