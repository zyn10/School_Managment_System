#pragma once
#define STUDENT_H_INCLUDED
#include<string>
#include<iostream>
#include<iomanip>
#include<fstream>
#include"threefile.h"
using namespace std;
class Student :public Admin
{
public:
	string Veiw[3];
	string choice;
	string find;
	bool check = false;
	void add();
	void veiw();
	void update();
	Date obj_date;
};
void Student::add()
{
	ofstream std;
	std.open("student.txt", ios::app);
	system("cls");
	cin.ignore();
	cout << "Enter student First Name:";
	getline(cin, std_firstName);
	int std_len, std_x = 0;
	std_len = std_firstName.length();
	//cout << "The length of the string is :" << std_len << endl;
	for (int i = 0; i < std_len; i++)
	{
		while (std_firstName[i] == '1' || std_firstName[i] == '2' || std_firstName[i] == '3' || std_firstName[i] == '4' || std_firstName[i] == '5' || std_firstName[i] == '6' || std_firstName[i] == '7' || std_firstName[i] == '8' || std_firstName[i] == '9' || std_firstName[i] == '0')
		{
			cout << "--->ERROR!\n Please Enter Correct First Name:\t";
			getline(cin, std_firstName);
		}
		if (std_firstName[i] != '1' || std_firstName[i] != '2' || std_firstName[i] != '3' || std_firstName[i] != '4' || std_firstName[i] != '5' || std_firstName[i] != '6' || std_firstName[i] != '7' || std_firstName[i] != '8' || std_firstName[i] != '9' || std_firstName[i] != '0')
		{
			std_x++;
			
		}
	}
	cout << "Enter student last Name:";
	getline(cin, std_lastName);
	int std_len2, std_x2 = 0;
	std_len2 = std_lastName.length();//finding string length
	for (int i = 0; i < std_len2; i++)
	{
		while (std_lastName[i] == '1' || std_lastName[i] == '2' || std_lastName[i] == '3' || std_lastName[i] == '4' || std_lastName[i] == '5' || std_lastName[i] == '6' || std_lastName[i] == '7' || std_lastName[i] == '8' || std_lastName[i] == '9' || std_lastName[i] == '0')
		{
			cout << "--->ERROR!\n Please Enter Correct Last Name:\t";
			getline(cin, std_lastName);
		}
		if (std_lastName[i] != '1' || std_lastName[i] != '2' || std_lastName[i] != '3' || std_lastName[i] != '4' || std_lastName[i] != '5' || std_lastName[i] != '6' || std_lastName[i] != '7' || std_lastName[i] != '8' || std_lastName[i] != '9' || std_lastName[i] != '0')
		{
			std_x2++;
			
		}
	}
	cout << "Enter Age:";
	while (!(cin >> age)) {  //checking the validity
		cout << "---> Error! \nInput Age again:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cout << "Enter Class (First to matric as 01,02 to 10 number):";
	while (!(cin >> Class) || Class > 10 || Class < 1) {  //checking the validity
		cout << "---> Error! \nEnter Class again:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	
	if (Class == 1)
	{
		static int generator1 = 0;//generator set to 0 for class 1
		rollNum = 001000 + generator1;
		++generator1;
	}
	else if (Class == 2)
	{
		static int generator2 = 0;//generator set to 0 for class 2
		rollNum = 002000 + generator2;
		++generator2;
	}
	else if (Class == 3)
	{
		static int generator3 = 0;//generator set to 0 for class 3
		rollNum = 003000 + generator3;
		++generator3;
	}
	else if (Class == 4)
	{
		static int generator4 = 0;//generator set to 0 for class 4
		rollNum = 004000 + generator4;
		++generator4;
	}
	else if (Class == 5)
	{
		static int generator5 = 0;//generator set to 0 for class 5
		rollNum = 005000 + generator5;
		++generator5;
	}
	else if (Class == 6)
	{
		static int generator6 = 0;//generator set to 0 for class 6
		rollNum = 006000 + generator6;
		++generator6;
	}
	else if (Class == 7)
	{
		static int generator7 = 0;//generator set to 0 for class 7
		rollNum = 007000 + generator7;
		++generator7;
	}
	else if (Class == 8)
	{
		static int generator8 = 0;//generator set to 0 for class 8
		rollNum = 8000 + generator8;//onvalid octal digit if we put zero in front
		++generator8;
	}
	else if (Class == 9)
	{
		static int generator9 = 0;//generator set to 0 for class 9
		rollNum = 9000 + generator9;
		++generator9;
	}
	else if (Class == 10)
	{
		static int generator10 = 0;//generator set to 0 for class 10
		rollNum = 010000 + generator10;
		++generator10;
	}
	cout << " Input the Registration Date.......... " << endl;
	cout << " Day                                 : ";
	while (!(cin >> obj_date.day) || obj_date.day > 31 || obj_date.day<1) {  //checking the validity
		cout << "---> Error!\n Please Enter Day Correcty:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cout << " Month                               : ";
	while (!(cin >> obj_date.month) || obj_date.month > 12 || obj_date.month<1) {  //checking the validity
		cout << "---> Error! \nPlease Enter Month Correcty:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cout << " Year                                : ";
	while (!(cin >> obj_date.year)) {  //checking the validity
		cout << "---> Error! \nPlease Enter Year Correcty:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cout << " Enter Gender                        : ";  cin >> Gender;

	while (Gender != 'm' && Gender != 'M' && Gender != 'f' && Gender != 'F')
	{
		cout << "invalid input" << endl;
		cin >> Gender;
	}
	cout << "Enter  Contact No (only 11 numbers)  : "; cin >> student_phone;
	int lenStd, x_Std = 0;
	lenStd = student_phone.length(); // finding length of string
	for (int i = 0; i < lenStd; i++)
	{
		while (student_phone[i] != '1' && student_phone[i] != '2' && student_phone[i] != '3' && student_phone[i] != '4' && student_phone[i] != '5' && student_phone[i] != '6' && student_phone[i] != '7' && student_phone[i] != '8' && student_phone[i] != '9' && student_phone[i] != '0')
		{
			cout << "---> ERROR!\n Kindly Enter Correct Phone Number:\t";
			getline(cin, student_phone);
		}
		if (student_phone[i] == '1' || student_phone[i] == '2' || student_phone[i] == '3' || student_phone[i] == '4' || student_phone[i] == '5' || student_phone[i] == '6' || student_phone[i] == '7' || student_phone[i] == '8' || student_phone[i] == '9' || student_phone[i] == '0')
		{
			x_Std++;
		}
	}
	cout << "Enter the Father Name                : "; getline(cin, fatherName);
	int len, x = 0;
	len = fatherName.length();
	for (int i = 0; i < len; i++)
	{
		while (fatherName[i] == '1' || fatherName[i] == '2' || fatherName[i] == '3' || fatherName[i] == '4' || fatherName[i] == '5' || fatherName[i] == '6' || fatherName[i] == '7' || fatherName[i] == '8' || fatherName[i] == '9' || fatherName[i] == '0')
		{
			cout << "---> ERROR!\n Please Enter Father Name:\t";
			getline(cin, fatherName);
		}
		if (fatherName[i] != '1' || fatherName[i] != '2' || fatherName[i] != '3' || fatherName[i] != '4' || fatherName[i] != '5' || fatherName[i] != '6' || fatherName[i] != '7' || fatherName[i] != '8' || fatherName[i] != '9' || fatherName[i] != '0')
		{
			x++;
			
		}
	}
	cout << "Father�s Profession                  : "; getline(cin, father_profession);
	cout << "Fathers Contact No (only 11 numbers) : "; cin >> father_phone;
	int lenPh, x_Ph = 0;
	lenPh = father_phone.length(); // finding length of string
	for (int i = 0; i < lenPh; i++)
	{
		while (father_phone[i] != '1' && father_phone[i] != '2' && father_phone[i] != '3' && father_phone[i] != '4' && father_phone[i] != '5' && father_phone[i] != '6' && father_phone[i] != '7' && father_phone[i] != '8' && father_phone[i] != '9' && father_phone[i] != '0')
		{
			cout << "---> ERROR!\n Kindly Enter Correct Phone Number:\t";
			getline(cin, father_phone);
		}
		if (father_phone[i] == '1' || father_phone[i] == '2' || father_phone[i] == '3' || father_phone[i] == '4' || father_phone[i] == '5' || father_phone[i] == '6' || father_phone[i] == '7' || father_phone[i] == '8' || father_phone[i] == '9' || father_phone[i] == '0')
		{
			x_Ph++;
			
		}
	}
asd:
	cout << "Is your fee have been submitted (y/n)  "; cin >> feeStatus;
	if (feeStatus == 'y')
	{
		cout << "Thank you for submitting the fee on time " << endl;
	}
	else if (feeStatus == 'n' || feeStatus == 'N')
	{
		cout << "Please submit your fee as soon as possible " << endl;
	}
	else
	{
		cout << "---> ERROR!\n Please Choose Correct Option:\t";
		goto asd;
	}
	cout << "Input your Blood Group               : ";
a:
	cin >> blood;
	int lenBlood, x_Blood = 0;
	lenBlood = blood.length();
	if (lenBlood > 2)
	{
		cout << "---> ERROR!\n Please Enter Blood Group Again:\t";
		goto a;
	}
	else if (blood != "A+"&& blood != "A-" && blood != "B+" && blood != "B-" && blood != "AB+" && blood != "AB-" && blood != "O+" && blood != "O-")
	{
		cout << "---> ERROR! Kindly Enter Correct Blood Group:\t";
		goto a;
	}
	cin.ignore();
	cout << "Enter the address " << endl;
	getline(cin, student_address);
	std << endl << rollNum << " " << std_firstName << " " << std_lastName << " "
		<< age << " " << Class << " "
		<< obj_date.day << "-" << obj_date.month << "-" << obj_date.year;
	std << " " << Gender << " "
		<< fatherName << " "
		<< father_profession << " "
		<< father_phone << " "
		<< feeStatus << " "
		<< blood << " "
		<< student_address;
	cout << "\nThis student Data has been Successfully saved in the data base " << endl;
	std.close();
}

void Student::update()
{
		ifstream std_out;
		std_out.open("student.txt");
		ofstream temp;
		temp.open("temp.txt");
		if (std_out.is_open())
		{
			cout << "Enter the roll number of student : "; cin >> find;
			while (!std_out.eof())
			{
				if (std_out.is_open())
				{
					int counter = 0;
					while (!std_out.eof())
					{
                        while (counter < 13)

						{
							std_out >> finder;
							temp << finder;
							temp << " ";
							if (counter == 0)

							{
								++counter;
								break;
							}
							++counter;
						}
						if (counter == 13)
							counter = 0;
						if (find == finder)
						{
							std_out >> finder;
							cin.ignore();
							cout << "Enter new student First Name:";
							getline(cin, std_firstName);
							int std_len, std_x = 0;
							std_len = std_firstName.length();
							//cout << "The length of the string is :" << std_len << endl;
							for (int i = 0; i < std_len; i++)
							{
								while (std_firstName[i] == '1' || std_firstName[i] == '2' || std_firstName[i] == '3' || std_firstName[i] == '4' || std_firstName[i] == '5' || std_firstName[i] == '6' || std_firstName[i] == '7' || std_firstName[i] == '8' || std_firstName[i] == '9' || std_firstName[i] == '0')
								{
									cout << "--->ERROR! Please Enter Correct First Name:\t";
									getline(cin, std_firstName);
								}
								if (std_firstName[i] != '1' || std_firstName[i] != '2' || std_firstName[i] != '3' || std_firstName[i] != '4' || std_firstName[i] != '5' || std_firstName[i] != '6' || std_firstName[i] != '7' || std_firstName[i] != '8' || std_firstName[i] != '9' || std_firstName[i] != '0')
								{
									std_x++;
									if (std_x == std_len)
									{
										cout << "Re-Entered First Name is (updated):\t" << std_firstName << endl;
									}
								}
							}
							temp << std_firstName;
							temp << " ";
							std_out >> finder;
							cout << "Enter new student last Name:";
							getline(cin, std_lastName);
							int std_len2, std_x2 = 0;
							std_len2 = std_lastName.length();//finding string length
							for (int i = 0; i < std_len2; i++)
							{
								while (std_lastName[i] == '1' || std_lastName[i] == '2' || std_lastName[i] == '3' || std_lastName[i] == '4' || std_lastName[i] == '5' || std_lastName[i] == '6' || std_lastName[i] == '7' || std_lastName[i] == '8' || std_lastName[i] == '9' || std_lastName[i] == '0')
								{
									cout << "--->ERROR! Please Enter Correct Last Name:\t";
									getline(cin, std_lastName);
								}
								if (std_lastName[i] != '1' || std_lastName[i] != '2' || std_lastName[i] != '3' || std_lastName[i] != '4' || std_lastName[i] != '5' || std_lastName[i] != '6' || std_lastName[i] != '7' || std_lastName[i] != '8' || std_lastName[i] != '9' || std_lastName[i] != '0')
								{
									std_x2++;
									if (std_x2 == std_len2)
									{
										cout << "Re-Entered Last Name is (updated):\t" << std_firstName << endl;
									}
								}
							}
							temp << std_lastName;
							temp << " ";
							for (int i = 0; i <= 3; i++)
							{
								std_out >> finder;
								temp << finder;
								temp << " ";

							}
							std_out >> finder;
							cout << "Enter new Contact No (only 11 numbers)  : "; cin >> student_phone;
							int lenStd, x_Std = 0;
							lenStd = student_phone.length(); // finding length of string
							for (int i = 0; i < lenStd; i++)
							{
								while (student_phone[i] != '1' && student_phone[i] != '2' && student_phone[i] != '3' && student_phone[i] != '4' && student_phone[i] != '5' && student_phone[i] != '6' && student_phone[i] != '7' && student_phone[i] != '8' && student_phone[i] != '9' && student_phone[i] != '0')
								{
									cout << "---> ERROR! Kindly Enter Correct Phone Number:\t";
									getline(cin, student_phone);
								}
								if (student_phone[i] == '1' || student_phone[i] == '2' || student_phone[i] == '3' || student_phone[i] == '4' || student_phone[i] == '5' || student_phone[i] == '6' || student_phone[i] == '7' || student_phone[i] == '8' || student_phone[i] == '9' || student_phone[i] == '0')
								{
									x_Std++;
									
								}
							}
							temp << student_phone;
							temp << " ";
							for (int i = 0; i < 3; i++)
							{
								std_out >> finder;
								temp << finder;
								temp << " ";

							}
							std_out >> finder;
						asd:
							cout << "Enter fee status (y/n)  "; cin >> feeStatus;
							if (feeStatus == 'y')
							{
								cout << "Thank you for submitting the fee on time " << endl;
							}
							else if (feeStatus == 'n' || feeStatus == 'N')
							{
								cout << "Please submit your fee as soon as possible " << endl;
							}
							else
							{
								cout << "---> ERROR! Please Choose Correct Option:\t";
								goto asd;
							}
							temp << feeStatus;
							temp << " ";

							std_out >> finder;
							temp << finder;
							temp << " ";


							std_out >> finder;
							cout << "Enter new address :";
							cin.ignore();
							getline(cin, student_address);
							temp << student_address;
							temp << endl;
							while (!std_out.eof())
							{
								std_out >> finder;
								temp << finder;
								temp << " ";

							}



						}
					}

				}
			}
		}
		temp.close();
		std_out.close();
		remove("student.txt");
		rename("temp.txt", "student.txt");
	}

void Student::veiw()
{
	ifstream std_veiw;
	std_veiw.open("Student.txt");
	if (std_veiw.is_open())
	{
		cout << "\nView student data\n";

		while (!std_veiw.eof())
		{
			if (counter < 4)
			{
				counter++;
				std_veiw >> finder;
				cout << finder << "\t\t";
			}
			else
			{
				++counter;
				std_veiw >> finder;
				if (counter == 13)
					counter = 0;
			}
			if (counter == 4)
				cout << endl;
		}

	}
	else
		cout << "Error in file opening";
	std_veiw.close();
}
