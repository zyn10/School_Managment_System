#pragma once
#define TEACHER_H_INCLUDED
#include<string>
#include<iostream>
#include<iomanip>
#include<fstream>
#include"threefile.h"
using namespace std;
class Courses;//forward declaration
class Teacher :public Admin
{
	string find;
	string matching;
	bool check;
	Date join_Date;
	Date DOB;
	int Salary;
public:
	void add();
	void veiw();
	void update();

};

void Teacher::add()
{
	ofstream teacher_add;
	teacher_add.open("teacher.txt", ios::app);
	system("cls");
	cout << "Enter Teacher First Name:";
	getline(cin, teacher_firstName);
	int tea_len, tea_x = 0;
	tea_len = teacher_firstName.length();
	//cout << "The length of the string is :" << tea_len << endl;
	for (int i = 0; i < tea_len; i++)
	{
		while (teacher_firstName[i] == '1' || teacher_firstName[i] == '2' || teacher_firstName[i] == '3' || teacher_firstName[i] == '4' || teacher_firstName[i] == '5' || teacher_firstName[i] == '6' || teacher_firstName[i] == '7' || teacher_firstName[i] == '8' || teacher_firstName[i] == '9' || teacher_firstName[i] == '0')
		{
			cout << "--->ERROR! Please Enter Correct First Name:\t";
			getline(cin, teacher_firstName);
		}
		if (teacher_firstName[i] != '1' || teacher_firstName[i] != '2' || teacher_firstName[i] != '3' || teacher_firstName[i] != '4' || teacher_firstName[i] != '5' || teacher_firstName[i] != '6' || teacher_firstName[i] != '7' || teacher_firstName[i] != '8' || teacher_firstName[i] != '9' || teacher_firstName[i] != '0')
		{
			tea_x++;
		}
	}
	//last name
	cout << "Enter Teacher last Name:";
	getline(cin, teacher_lastName);
	int tea_len2, tea_x2 = 0;
	tea_len2 = teacher_lastName.length();//finding string length
	for (int i = 0; i < tea_len2; i++)
	{
		while (teacher_lastName[i] == '1' || teacher_lastName[i] == '2' || teacher_lastName[i] == '3' || teacher_lastName[i] == '4' || teacher_lastName[i] == '5' || teacher_lastName[i] == '6' || teacher_lastName[i] == '7' || teacher_lastName[i] == '8' || teacher_lastName[i] == '9' || teacher_lastName[i] == '0')
		{
			cout << "--->ERROR! Please Enter Correct Last Name:\t";
			getline(cin, teacher_lastName);
		}
		if (teacher_lastName[i] != '1' || teacher_lastName[i] != '2' || teacher_lastName[i] != '3' || teacher_lastName[i] != '4' || teacher_lastName[i] != '5' || teacher_lastName[i] != '6' || teacher_lastName[i] != '7' || teacher_lastName[i] != '8' || teacher_lastName[i] != '9' || teacher_lastName[i] != '0')
		{
			tea_x2++;
		}
	}
	cout << "Enter your Email Addres" << endl;
	getline(cin, teacher_email);

	//checking valid DATE
	cout << " Input the Joining Date.......... " << endl;
	cout << " Day                                 : ";
	while (!(cin >> join_Date.day) || join_Date.day > 31 || join_Date.day < 1) {  //checking the validity
		cout << "---> Error! Please Enter Day Correcty:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cout << " Month                               : ";
	while (!(cin >> join_Date.month) || join_Date.month > 12 || join_Date.month < 1) {  //checking the validity
		cout << "---> Error! Please Enter Month Correcty:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cout << " Year                                : ";
	while (!(cin >> join_Date.year)) {  //checking the validity
		cout << "---> Error! Please Enter Year Correcty:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cin.ignore();
	cout << "Enter your password" << endl;
	getline(cin, password);
	cout << "Enter your Confirm Password" << endl;
	getline(cin, confirmation);
	cout << "Enter your CNIC" << endl;
	getline(cin, CNIC);
	cout << " Enter Gender                        : ";  cin >> Gender;
	while (Gender != 'm' && Gender != 'M' && Gender != 'f' && Gender != 'F')
	{
		cout << "---> ERROR! Please Enter Gender Again:\t";
		cin >> Gender;
	}

	cout << "Enter your Qualification â®š (Computer, Mechanical, Mathematics, Commerce)" << endl;
	cin >> qualification;
	int qua_len2, qua_x2 = 0;
	qua_len2 = qualification.length();//finding string length
	for (int i = 0; i < qua_len2; i++)
	{
		while (qualification[i] == '1' || qualification[i] == '2' || qualification[i] == '3' || qualification[i] == '4' || qualification[i] == '5' || qualification[i] == '6' || qualification[i] == '7' || qualification[i] == '8' || qualification[i] == '9' || qualification[i] == '0')
		{
			cout << "--->ERROR! Please Enter Correct Qualification:\t";
			cin >> qualification;
		}
		if (qualification[i] != '1' || qualification[i] != '2' || qualification[i] != '3' || qualification[i] != '4' || qualification[i] != '5' || qualification[i] != '6' || qualification[i] != '7' || qualification[i] != '8' || qualification[i] != '9' || qualification[i] != '0')
		{
			qua_x2++;
		}
	}


	cout << "Enter  Contact No (only 11 numbers)  : "; cin >> teacher_phone;
	int lenTea, x_Tea = 0;
	lenTea = teacher_phone.length(); // finding length of string
	for (int i = 0; i < lenTea; i++)
	{
		while (teacher_phone[i] != '1' && teacher_phone[i] != '2' && teacher_phone[i] != '3' && teacher_phone[i] != '4' && teacher_phone[i] != '5' && teacher_phone[i] != '6' && teacher_phone[i] != '7' && teacher_phone[i] != '8' && teacher_phone[i] != '9' && teacher_phone[i] != '0')
		{
			cout << "---> ERROR! Kindly Enter Correct Phone Number:\t";
			getline(cin, teacher_phone);
		}
		if (teacher_phone[i] == '1' || teacher_phone[i] == '2' || teacher_phone[i] == '3' || teacher_phone[i] == '4' || teacher_phone[i] == '5' || teacher_phone[i] == '6' || teacher_phone[i] == '7' || teacher_phone[i] == '8' || teacher_phone[i] == '9' || teacher_phone[i] == '0')
		{
			x_Tea++;
		}
	}
	cout << "Enter your Date of birth" << endl;
	cout << " Day                                 : ";
	while (!(cin >> DOB.day) || DOB.day > 31 || DOB.day < 1) {  //checking the validity
		cout << "---> Error! Please Enter Day Correcty:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cout << " Month                               : ";
	while (!(cin >> DOB.month) || DOB.month > 12 || DOB.month < 1) {  //checking the validity
		cout << "---> Error! Please Enter Month Correcty:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cout << " Year                                : ";
	while (!(cin >> DOB.year)) {  //checking the validity
		cout << "---> Error! Please Enter Year Correcty:\t";
		cin.clear();
		cin.ignore(123, '\n');
	}
	cin.ignore();
	cout << "Enter your Address " << endl;
	getline(cin, teacher_address);
	cout << "Enter your Salary : ";
	cin >> Salary;
	teacher_add << endl << CNIC
		<< " " << teacher_firstName
		<< " " << teacher_lastName
		<< " " << teacher_email
		<< " " << join_Date.day << "-" << join_Date.month << "-" << join_Date.year
		<< " " << password << " " << confirmation
		<< " " << Gender
		<< " " << qualification << " " << teacher_phone
		<< " " << DOB.day << "-" << DOB.month << "-" << DOB.year
		<< " " << teacher_address
		<< " " << Salary;

	teacher_add.open("teacher.txt", ios::app);
	system("cls");


}
void Teacher::update()
{
	ifstream tchr_out;
	tchr_out.open("teacher.txt");
	ofstream temp;
	temp.open("temp.txt");
	if (tchr_out.is_open())
	{
		cout << "\nEnter the CNIC number of Teacher : "; cin >> find;
		while (!tchr_out.eof())
		{
			if (tchr_out.is_open())
			{

				int counter = 0;
				while (!tchr_out.eof())
				{
					while (counter < 13)

					{
						tchr_out >> finder;
						temp << finder;
						temp << " ";
						if (counter == 0)

						{
							++counter;
							break;
						}
						++counter;
					}
					if (counter == 13)
						counter = 0;

					if (find == finder)
					{
						for (int i = 1; i <= 7; i++)
						{
							tchr_out >> finder;
							temp << finder;
							temp << " ";

						}
						tchr_out >> finder;
						cin.ignore();
						cout << "Enter your Qualification (updated) (Computer, Mechanical, Mathematics, Commerce)" << endl;
						cin >> qualification;
						int qua_len2, qua_x2 = 0;
						qua_len2 = qualification.length();//finding string length
						for (int i = 0; i < qua_len2; i++)
						{
							while (qualification[i] == '1' || qualification[i] == '2' || qualification[i] == '3' || qualification[i] == '4' || qualification[i] == '5' || qualification[i] == '6' || qualification[i] == '7' || qualification[i] == '8' || qualification[i] == '9' || qualification[i] == '0')
							{
								cout << "--->ERROR! Please Enter Correct Qualification:\t";
								cin >> qualification;
							}
							if (qualification[i] != '1' || qualification[i] != '2' || qualification[i] != '3' || qualification[i] != '4' || qualification[i] != '5' || qualification[i] != '6' || qualification[i] != '7' || qualification[i] != '8' || qualification[i] != '9' || qualification[i] != '0')
							{
								qua_x2++;
							}
						}
						temp << qualification;
						temp << " ";
						tchr_out >> finder;
						cout << "Enter New Contact No (only 11 numbers)  : "; cin >> teacher_phone;
						int lenTea, x_Tea = 0;
						lenTea = teacher_phone.length();   // finding length of string
						for (int i = 0; i < lenTea; i++)
						{
							while (teacher_phone[i] != '1' && teacher_phone[i] != '2' && teacher_phone[i] != '3' && teacher_phone[i] != '4' && teacher_phone[i] != '5' && teacher_phone[i] != '6' && teacher_phone[i] != '7' && teacher_phone[i] != '8' && teacher_phone[i] != '9' && teacher_phone[i] != '0')
							{
								cout << "---> ERROR! Kindly Enter Correct Phone Number:\t";
								getline(cin, teacher_phone);
							}
							if (teacher_phone[i] == '1' || teacher_phone[i] == '2' || teacher_phone[i] == '3' || teacher_phone[i] == '4' || teacher_phone[i] == '5' || teacher_phone[i] == '6' || teacher_phone[i] == '7' || teacher_phone[i] == '8' || teacher_phone[i] == '9' || teacher_phone[i] == '0')
							{
								x_Tea++;
							}
						}
						temp << teacher_phone;
						temp << " ";

						tchr_out >> finder;
						temp << finder;
						temp << " ";

						tchr_out >> finder;
						cin.ignore();
						cout << "Enter new Addres "; getline(cin, teacher_address);
						temp << teacher_address;
						temp << " ";

						tchr_out >> finder;
						cout << "Enter new Salary :";
						cin >> Salary;
						temp << Salary;
						temp << endl;
						while (!tchr_out.eof())
						{
							tchr_out >> finder;
							temp << finder;
							temp << " ";

						}
					}
				}
			}
		}
	}
	temp.close();
	tchr_out.close();
	remove("teacher.txt");
	rename("temp.txt", "teacher.txt");
}
void Teacher::veiw()
{
	ifstream teacher_in;
	teacher_in.open("teacher.txt");
	if (teacher_in.is_open())
	{

		while (!teacher_in.eof())
		{
			++counter;
			teacher_in >> finder;
			if (counter == 1 || counter == 2 || counter == 3 || counter == 8 || counter == 9 || counter == 10)
				cout << finder << "  " << left << setw(10);
			if (counter == 13)
			{
				cout << endl;
				counter = 0;
			}
		}
	}
	teacher_in.close();



}