#include<iostream>
#include<string>
#include<string.h>
#include<ctime>
#include<cstdlib>
#include<fstream>
#include"Student.h"
using namespace std;
void Student::add()
{	
system("cls");
	std.open("student.txt", ios::app);
	Student info[99];
	i = 0;
	do 
	{	
		cin.ignore(1);
		cout << "Enter First Name : ";
		getline(cin,info[i].firstName);
		cout << "Enter Last Name  : ";
		getline(cin,info[i].lastName);
		cout << "Enter Gender    : ";
		cin >> info[i].gender;
				//if (gender == 'm' || gender == 'm' || gender == 'f' || gender == 'F' )
			cout << "Enter Class (First to matric as 01,02 to 10 number):";
			cin >> info[i].Class;
			while (Class < 1 || Class>10)
			{
				cout << "Invalid Input" << endl;
				cin >> info[i].Class;
			}
			srand(time(NULL));
			info[i].rollNo = rand() % 1000;
			while (info[i].rollNo<info[i-1].rollNo)
			{
				info[i].rollNo = rand() % 10000;
			}
		std << endl << info[i].firstName << "," << info[i].lastName << "," << info[i].gender << ","
			<<"0"<< info[i].Class << info[i].rollNo;

		cout << "Do you want to Enter another entery(y/n):";

		cin >> chk;
	} while (chk == 'y' || chk == 'Y');
	std.close();
	system("pause");
	return;
}