#include<iostream>
#include<string>
#include<string.h>
#include<fstream>
#include"Person.h"
using namespace std;
class Person;
class Student :public Person
{ private:
	int Class;
	int rollNo;
	ofstream std;
	char chk;//for entering another student or not
	int i;//for file handling wali loop
public:
	void add();
	void del();
	void show();
	void update();
	void search();

};
